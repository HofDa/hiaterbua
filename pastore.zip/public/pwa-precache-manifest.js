self.__PWA_PRECACHE_MANIFEST = {
  "version": "mAaYI4wlHIhKvO15MMIDT",
  "routes": [
    {
      "path": "/",
      "dataRoute": "/index.rsc"
    },
    {
      "path": "/_global-error",
      "dataRoute": "/_global-error.rsc"
    },
    {
      "path": "/_not-found",
      "dataRoute": "/_not-found.rsc"
    },
    {
      "path": "/enclosures",
      "dataRoute": "/enclosures.rsc"
    },
    {
      "path": "/export",
      "dataRoute": "/export.rsc"
    },
    {
      "path": "/favicon.ico",
      "dataRoute": null
    },
    {
      "path": "/herd",
      "dataRoute": "/herd.rsc"
    },
    {
      "path": "/herd/edit",
      "dataRoute": "/herd/edit.rsc"
    },
    {
      "path": "/herds",
      "dataRoute": "/herds.rsc"
    },
    {
      "path": "/session",
      "dataRoute": "/session.rsc"
    },
    {
      "path": "/sessions",
      "dataRoute": "/sessions.rsc"
    },
    {
      "path": "/settings",
      "dataRoute": "/settings.rsc"
    },
    {
      "path": "/work",
      "dataRoute": "/work.rsc"
    }
  ],
  "urls": [
    "/",
    "/_global-error",
    "/_next/static/chunks/05f6971a.b186f38147d24bcb.js",
    "/_next/static/chunks/111-7bd5d206591361dc.js",
    "/_next/static/chunks/116-62d6a9bc6569e2de.js",
    "/_next/static/chunks/274-640f1ae54d9bf6db.js",
    "/_next/static/chunks/477-5ccdaa3a3bf65785.js",
    "/_next/static/chunks/4bd1b696-f9fb033f25886fd3.js",
    "/_next/static/chunks/500-5d45efbf86b8d36e.js",
    "/_next/static/chunks/553-4fdac4f451955958.js",
    "/_next/static/chunks/602-7f09c0711f64f453.js",
    "/_next/static/chunks/635-f67de10cd0012154.js",
    "/_next/static/chunks/761-35bff67f905c157a.js",
    "/_next/static/chunks/764.87ee53f48dfad628.js",
    "/_next/static/chunks/771.5f28f782cb66257e.js",
    "/_next/static/chunks/794-32443f99e6c8f194.js",
    "/_next/static/chunks/973-62efbb9c8d94220a.js",
    "/_next/static/chunks/app/_global-error/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/_not-found/page-75f8e505bce85ff2.js",
    "/_next/static/chunks/app/enclosures/page-63cdfa402af0841c.js",
    "/_next/static/chunks/app/export/page-6e11cdc72a2dc8ae.js",
    "/_next/static/chunks/app/herd/edit/page-a61935b61781f991.js",
    "/_next/static/chunks/app/herd/page-80ca10e66587811c.js",
    "/_next/static/chunks/app/herds/[id]/edit/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/herds/[id]/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/herds/page-ec1d11593004702b.js",
    "/_next/static/chunks/app/layout-4f3ee9d133d2ea25.js",
    "/_next/static/chunks/app/page-4b2f14841bb867c5.js",
    "/_next/static/chunks/app/session/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/sessions/page-eb779a02f5a7b186.js",
    "/_next/static/chunks/app/settings/page-b753b7547a34a2d7.js",
    "/_next/static/chunks/app/work/page-48c612706646b2ec.js",
    "/_next/static/chunks/framework-747382f602876dbf.js",
    "/_next/static/chunks/main-a0d0ee2abdc892cd.js",
    "/_next/static/chunks/main-app-1a10d56d48ecb598.js",
    "/_next/static/chunks/next/dist/client/components/builtin/app-error-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/forbidden-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/global-error-4c0d88c11e8d3eeb.js",
    "/_next/static/chunks/next/dist/client/components/builtin/not-found-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/unauthorized-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/polyfills-42372ed130431b0a.js",
    "/_next/static/chunks/webpack-84310a74f19065f9.js",
    "/_next/static/css/59843858e068edca.css",
    "/_next/static/css/badba33cb5f06cfc.css",
    "/_next/static/mAaYI4wlHIhKvO15MMIDT/_buildManifest.js",
    "/_next/static/mAaYI4wlHIhKvO15MMIDT/_ssgManifest.js",
    "/_next/static/media/27834908180db20f-s.p.woff2",
    "/_not-found",
    "/enclosures",
    "/export",
    "/favicon.ico",
    "/file.svg",
    "/globe.svg",
    "/herd",
    "/herd/edit",
    "/herds",
    "/icon-512.png",
    "/icon.png",
    "/manifest.webmanifest",
    "/next.svg",
    "/offline.html",
    "/session",
    "/sessions",
    "/settings",
    "/vercel.svg",
    "/window.svg",
    "/work"
  ]
};
