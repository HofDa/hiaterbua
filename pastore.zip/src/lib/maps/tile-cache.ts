import Dexie, { type Table } from 'dexie'
import { logError } from '@/lib/utils/log'
import type { MapBaseLayer } from '@/types/domain'
import type { MapTileRecord } from '@/types/domain'

export const TILE_CACHE_NAME = 'hirtenapp-map-tiles-v1'
export const TILE_DB_NAME = 'hirtenapp-tile-db'
export const MAX_PREFETCH_TILES = 1200
export const PREFETCH_CONCURRENCY = 8
// Hard ceiling on how many tiles persist in IndexedDB. A single prefetch is
// capped at MAX_PREFETCH_TILES, but repeated prefetches across different field
// areas would otherwise grow the cache without bound — and persistent storage
// makes the browser unlikely to evict it for us. ~5000 256px tiles is roughly
// 150-250 MB depending on the layer; oldest tiles are trimmed past this.
// The service worker enforces the same ceiling on its runtime tile store — keep this
// in sync with MAX_CACHED_TILES in public/sw/shared.js.
export const MAX_CACHED_TILES = 5000
export const TILE_CACHE_CHANGED_EVENT = 'hirtenapp:tile-cache-changed'

export type PrefetchTileResult = {
  succeeded: number
  failed: number
  total: number
}

export const tileTemplates: Record<MapBaseLayer, string> = {
  'south-tyrol-orthophoto-2023':
    'https://geoservices.buergernetz.bz.it/mapproxy/ows?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=p_bz-Orthoimagery:Aerial-2023-RGB&STYLES=&CRS=EPSG:3857&BBOX={bbox-epsg-3857}&WIDTH=256&HEIGHT=256&FORMAT=image/jpeg',
  'south-tyrol-basemap':
    'https://geoservices.buergernetz.bz.it/mapproxy/ows?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=p_bz-BaseMap:Basemap-Standard&STYLES=&CRS=EPSG:3857&BBOX={bbox-epsg-3857}&WIDTH=256&HEIGHT=256&FORMAT=image/png',
}

export type TileBounds = {
  north: number
  south: number
  east: number
  west: number
}

export const SOUTH_TYROL_BOUNDS: TileBounds = {
  north: 47.0921,
  south: 45.6726,
  east: 12.4718,
  west: 10.3567,
}

class TileCacheDB extends Dexie {
  mapTiles!: Table<MapTileRecord, string>

  constructor() {
    super(TILE_DB_NAME)

    this.version(2).stores({
      mapTiles: 'url, updatedAt',
    })

    this.version(3).stores({
      mapTiles: 'url, updatedAt',
      tileCacheSettings: 'key',
    })
  }
}

const tileDb = new TileCacheDB()

function dispatchTileCacheChanged() {
  if (typeof window === 'undefined') {
    return
  }

  window.dispatchEvent(new CustomEvent(TILE_CACHE_CHANGED_EVENT))
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value))
}

function lonToTileX(lon: number, zoom: number) {
  return Math.floor(((lon + 180) / 360) * 2 ** zoom)
}

function latToTileY(lat: number, zoom: number) {
  const safeLat = clamp(lat, -85.05112878, 85.05112878)
  const radians = (safeLat * Math.PI) / 180
  const mercator = Math.log(Math.tan(Math.PI / 4 + radians / 2))
  return Math.floor(((1 - mercator / Math.PI) / 2) * 2 ** zoom)
}

function tileToBBox3857(x: number, y: number, zoom: number) {
  const worldExtent = 20037508.342789244
  const tileCount = 2 ** zoom
  const tileSpan = (worldExtent * 2) / tileCount
  const minX = -worldExtent + x * tileSpan
  const maxX = minX + tileSpan
  const maxY = worldExtent - y * tileSpan
  const minY = maxY - tileSpan

  return [minX, minY, maxX, maxY].map((value) => value.toFixed(6)).join(',')
}

export function getPrefetchBounds(lat: number, lon: number, radiusKm: number) {
  const latDelta = radiusKm / 110.574
  const lonDelta = radiusKm / (111.32 * Math.max(Math.cos((lat * Math.PI) / 180), 0.2))

  return {
    north: clamp(lat + latDelta, -85.05112878, 85.05112878),
    south: clamp(lat - latDelta, -85.05112878, 85.05112878),
    east: clamp(lon + lonDelta, -180, 180),
    west: clamp(lon - lonDelta, -180, 180),
  }
}

export function buildPrefetchUrlsForBounds(
  layers: MapBaseLayer[],
  bounds: TileBounds,
  minZoom: number,
  maxZoom: number
) {
  const urls: string[] = []

  for (let zoom = minZoom; zoom <= maxZoom; zoom += 1) {
    const maxTileIndex = 2 ** zoom - 1
    const xMin = clamp(lonToTileX(bounds.west, zoom), 0, maxTileIndex)
    const xMax = clamp(lonToTileX(bounds.east, zoom), 0, maxTileIndex)
    const yMin = clamp(latToTileY(bounds.north, zoom), 0, maxTileIndex)
    const yMax = clamp(latToTileY(bounds.south, zoom), 0, maxTileIndex)

    for (let x = xMin; x <= xMax; x += 1) {
      for (let y = yMin; y <= yMax; y += 1) {
        const bbox = tileToBBox3857(x, y, zoom)

        layers.forEach((layer) => {
          urls.push(tileTemplates[layer].replace('{bbox-epsg-3857}', bbox))
        })
      }
    }
  }

  return urls
}

export function buildPrefetchUrlsForRadius(
  layers: MapBaseLayer[],
  lat: number,
  lon: number,
  radiusKm: number,
  minZoom: number,
  maxZoom: number
) {
  return buildPrefetchUrlsForBounds(
    layers,
    getPrefetchBounds(lat, lon, radiusKm),
    minZoom,
    maxZoom
  )
}

// Defaults for the one-tap "secure the area I'm standing in" home action: a
// ~2 km radius at walking detail. Deliberately lighter than the settings
// high-detail preset (no zoom 17) so a single layer stays well under
// MAX_PREFETCH_TILES and the action finishes quickly in the field.
export const SECURE_AREA_RADIUS_KM = 2
export const SECURE_AREA_MIN_ZOOM = 13
export const SECURE_AREA_MAX_ZOOM = 16

export function buildSecureAreaPrefetchUrls(
  layers: MapBaseLayer[],
  lat: number,
  lon: number
) {
  return buildPrefetchUrlsForRadius(
    layers,
    lat,
    lon,
    SECURE_AREA_RADIUS_KM,
    SECURE_AREA_MIN_ZOOM,
    SECURE_AREA_MAX_ZOOM
  )
}

export async function getTileCacheCount() {
  if (typeof window === 'undefined') {
    return null
  }

  try {
    return await tileDb.mapTiles.count()
  } catch (error) {
    logError('getTileCacheCount', error)
    return null
  }
}

export async function clearTileCacheStorage() {
  if (typeof window === 'undefined') {
    return false
  }

  try {
    await tileDb.mapTiles.clear()

    if ('caches' in window) {
      await window.caches.delete(TILE_CACHE_NAME)
    }

    dispatchTileCacheChanged()
    return true
  } catch (error) {
    logError('clearTileCacheStorage', error)
    return false
  }
}

/**
 * Evicts the oldest tiles (by `updatedAt`) once the cache exceeds `limit`,
 * Best-effort: failures are logged and swallowed so a trim never breaks the
 * prefetch that triggered it. Returns the number of tiles removed.
 */
export async function trimTileCacheToLimit(limit = MAX_CACHED_TILES): Promise<number> {
  if (typeof window === 'undefined') {
    return 0
  }

  try {
    const total = await tileDb.mapTiles.count()
    const overflow = total - limit
    if (overflow <= 0) {
      return 0
    }

    const staleTiles = await tileDb.mapTiles.orderBy('updatedAt').limit(overflow).toArray()
    if (staleTiles.length === 0) {
      return 0
    }

    const staleUrls = staleTiles.map((tile) => tile.url)
    await tileDb.mapTiles.bulkDelete(staleUrls)

    return staleUrls.length
  } catch (error) {
    logError('trimTileCacheToLimit', error)
    return 0
  }
}

export async function getPersistentStorageStatus() {
  if (typeof navigator === 'undefined' || !navigator.storage?.persisted) {
    return null
  }

  try {
    return await navigator.storage.persisted()
  } catch (error) {
    logError('getPersistentStorageStatus', error)
    return null
  }
}

export async function requestPersistentStorage() {
  if (typeof navigator === 'undefined' || !navigator.storage?.persist) {
    return null
  }

  try {
    return await navigator.storage.persist()
  } catch (error) {
    logError('requestPersistentStorage', error)
    return null
  }
}

async function persistTileResponseBestEffort(request: Request, response: Response) {
  try {
    const blob = await response.clone().blob()
    await tileDb.mapTiles.put({
      url: request.url,
      blob,
      contentType: response.headers.get('content-type') ?? undefined,
      status: response.status,
      statusText: response.statusText || undefined,
      updatedAt: new Date().toISOString(),
    })
    return true
  } catch (error) {
    logError('persistTileResponseBestEffort.db', error)
    return false
  }
}

export async function prefetchTileUrls(
  urls: string[],
  onProgress?: (completed: number, total: number) => void
): Promise<PrefetchTileResult> {
  if (typeof window === 'undefined') {
    throw new Error('Browser-APIs sind nicht verfuegbar.')
  }

  let completed = 0
  let succeeded = 0
  let failed = 0
  let firstTileError: unknown = null

  try {
    for (let index = 0; index < urls.length; index += PREFETCH_CONCURRENCY) {
      const batch = urls.slice(index, index + PREFETCH_CONCURRENCY)

      await Promise.all(
        batch.map(async (url) => {
          try {
            const request = new Request(url, {
              method: 'GET',
              mode: 'cors',
              cache: 'reload',
            })
            const response = await fetch(request)

            if (!response.ok) {
              throw new Error(`Tile konnte nicht geladen werden: ${response.status}`)
            }

            const didPersist = await persistTileResponseBestEffort(request, response)
            if (!didPersist) {
              throw new Error('Tile konnte nicht lokal gespeichert werden.')
            }

            succeeded += 1
          } catch (error) {
            failed += 1
            firstTileError ??= error
          } finally {
            completed += 1
            onProgress?.(completed, urls.length)
          }
        })
      )
    }
  } finally {
    // Enforce the cache ceiling before announcing the change so listeners read
    // the trimmed count.
    await trimTileCacheToLimit()
    dispatchTileCacheChanged()
  }

  if (failed > 0 && firstTileError) {
    logError('prefetchTileUrls.failedTiles', {
      failed,
      total: urls.length,
      firstError: firstTileError,
    })
  }

  return {
    succeeded,
    failed,
    total: urls.length,
  }
}
