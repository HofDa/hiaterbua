'use client'

import { useState } from 'react'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { assertUpdated } from '@/lib/db/assert-updated'
import { deleteHerdCascade } from '@/lib/db/delete-herd'
import { updateHerdRecord } from '@/lib/db/repositories/herds'
import { safeString } from '@/lib/herds/herd-detail-helpers'
import type { Herd } from '@/types/domain'

type UseHerdDetailMetaControllerOptions = {
  herd: Herd
  onDeleted: () => void
}

export function useHerdDetailMetaController({
  herd,
  onDeleted,
}: UseHerdDetailMetaControllerOptions) {
  const confirm = useConfirm()
  const [metaName, setMetaName] = useState(herd.name)
  const [metaFallbackCount, setMetaFallbackCount] = useState(
    herd.fallbackCount === null || herd.fallbackCount === undefined
      ? ''
      : String(herd.fallbackCount)
  )
  const [metaNotes, setMetaNotes] = useState(herd.notes ?? '')
  const [metaSaving, setMetaSaving] = useState(false)
  const [metaSaved, setMetaSaved] = useState(false)
  const [metaError, setMetaError] = useState('')

  const metaDirty =
    metaName.trim() !== safeString(herd.name) ||
    metaFallbackCount !==
      (herd.fallbackCount === null || herd.fallbackCount === undefined
        ? ''
        : String(herd.fallbackCount)) ||
    metaNotes.trim() !== safeString(herd.notes)

  async function deleteHerd() {
    const confirmed = await confirm({
      title: `Herde "${herd.name}" löschen?`,
      description:
        'Tiere, Weidegänge, Arbeitseinsätze und Belegungen dieser Herde werden ebenfalls entfernt.',
      confirmLabel: 'Löschen',
      destructive: true,
    })

    if (!confirmed) return

    setMetaSaving(true)
    setMetaError('')

    try {
      await deleteHerdCascade(herd.id)
      onDeleted()
    } catch {
      setMetaError('Herde konnte nicht gelöscht werden.')
    } finally {
      setMetaSaving(false)
    }
  }

  async function saveHerdMeta(event: React.FormEvent) {
    event.preventDefault()
    if (!metaName.trim()) return

    setMetaSaving(true)
    setMetaSaved(false)
    setMetaError('')

    try {
      const updatedCount = await updateHerdRecord(herd.id, {
        name: metaName.trim(),
        fallbackCount: metaFallbackCount.trim() ? Number(metaFallbackCount) : null,
        notes: metaNotes.trim() || undefined,
      })

      assertUpdated(updatedCount, 'Herde wurde nicht gefunden.')

      setMetaSaved(true)
    } catch {
      setMetaError('Herdendaten konnten nicht gespeichert werden.')
    } finally {
      setMetaSaving(false)
    }
  }

  return {
    metaName,
    metaFallbackCount,
    metaNotes,
    metaSaving,
    metaSaved,
    metaError,
    metaDirty,
    setMetaName,
    setMetaFallbackCount,
    setMetaNotes,
    deleteHerd,
    saveHerdMeta,
  }
}
