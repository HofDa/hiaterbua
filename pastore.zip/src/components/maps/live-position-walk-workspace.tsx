'use client'

import type { FormEvent } from 'react'
import { formatAccuracy, formatArea, formatTimestamp } from '@/lib/maps/map-core'
import { formatPointTimestamp } from '@/lib/maps/live-position-map-helpers'
import { FormField, FormLabel, FormInput, FormTextarea, FormButton } from '@/components/ui/form'
import { ErrorAlert } from '@/components/ui/alert'
import { cn } from '@/lib/utils/cn'
import type { PositionData } from '@/components/maps/live-position-map-types'

type LivePositionWalkWorkspaceProps = {
  isDrawing: boolean
  isWalking: boolean
  walkPoints: PositionData[]
  walkAreaM2: number
  walkName: string
  walkNotes: string
  walkError: string
  isWalkSaving: boolean
  isWalkPointsOpen: boolean
  selectedWalkPointIndex: number | null
  selectedWalkPoint: PositionData | null
  showControls: boolean
  showStatusText: boolean
  showHint: boolean
  onToggleWalkPoints: () => void
  onSelectedWalkPointIndexChange: (index: number | null) => void
  onStartWalkMode: () => void
  onStopWalkMode: () => void
  onUndoLastWalkPoint: () => void
  onRemoveWalkPointAtIndex: (index: number) => void
  onDiscardWalkMode: () => void
  onWalkNameChange: (value: string) => void
  onWalkNotesChange: (value: string) => void
  onSubmit: (event: FormEvent<HTMLFormElement>) => void
}

export function LivePositionWalkWorkspace({
  isDrawing,
  isWalking,
  walkPoints,
  walkAreaM2,
  walkName,
  walkNotes,
  walkError,
  isWalkSaving,
  isWalkPointsOpen,
  selectedWalkPointIndex,
  selectedWalkPoint,
  showControls,
  showStatusText,
  showHint,
  onToggleWalkPoints,
  onSelectedWalkPointIndexChange,
  onStartWalkMode,
  onStopWalkMode,
  onUndoLastWalkPoint,
  onRemoveWalkPointAtIndex,
  onDiscardWalkMode,
  onWalkNameChange,
  onWalkNotesChange,
  onSubmit,
}: LivePositionWalkWorkspaceProps) {
  const walkStatusText = isWalking
    ? 'GPS-Aufnahme laeuft. Punkte werden direkt auf der Karte markiert.'
    : 'Walk starten und den Pferch mit GPS-Punkten abgehen.'
  const averageAccuracy =
    walkPoints.length > 0
      ? walkPoints.reduce((sum, point) => sum + point.accuracy, 0) / walkPoints.length
      : null
  const latestPoint = walkPoints.length > 0 ? walkPoints[walkPoints.length - 1] : null

  return (
    <>
      {showStatusText ? (
        <p className="mt-2 text-sm text-ink-muted">{walkStatusText}</p>
      ) : null}
      {showHint ? (
        <p className="mt-2 text-xs font-medium text-ink-muted">
          Walk-Punkte können direkt auf der Karte angetippt und bearbeitet werden.
        </p>
      ) : null}

      {showControls ? (
        <div className="mt-4 space-y-3">
          <button
            type="button"
            onClick={onStartWalkMode}
            className="min-h-16 w-full rounded-[1.3rem] border-2 border-border-strong bg-accent px-4 py-4 text-base font-semibold text-ink shadow-sm disabled:opacity-50"
            disabled={isWalking || isDrawing}
          >
            GPS-Aufnahme starten
          </button>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={onStopWalkMode}
              className="min-h-16 rounded-[1.2rem] border border-border-strong bg-surface-muted px-4 py-4 text-sm font-semibold text-ink-strong disabled:opacity-50"
              disabled={!isWalking}
            >
              Aufnahme stoppen
            </button>
            <button
              type="button"
              onClick={onUndoLastWalkPoint}
              className="min-h-16 rounded-[1.2rem] border border-border bg-surface-raised px-4 py-4 text-sm font-semibold text-ink-strong disabled:opacity-50"
              disabled={walkPoints.length === 0}
            >
              Letzten Punkt löschen
            </button>
            <button
              type="button"
              onClick={() => {
                if (selectedWalkPointIndex !== null) {
                  onRemoveWalkPointAtIndex(selectedWalkPointIndex)
                }
              }}
              className="min-h-16 rounded-[1.2rem] border border-border bg-surface-raised px-4 py-4 text-sm font-semibold text-ink-strong disabled:opacity-50"
              disabled={selectedWalkPointIndex === null}
            >
              Ausgewählten Punkt löschen
            </button>
            <button
              type="button"
              onClick={onDiscardWalkMode}
              className="min-h-16 rounded-[1.2rem] border border-border-strong bg-surface-muted px-4 py-4 text-sm font-semibold text-ink-strong disabled:opacity-50"
              disabled={walkPoints.length === 0 && !isWalking}
            >
              Walk verwerfen
            </button>
          </div>
        </div>
      ) : null}

      <div className="mt-4 rounded-[1.1rem] border border-border bg-surface-raised px-4 py-3 text-sm text-ink-soft shadow-sm">
        Akzeptierte Walk-Punkte:{' '}
        <span className="font-medium text-ink">{walkPoints.length}</span>
        <span className="ml-2">
          · Fläche <span className="font-medium text-ink">{formatArea(walkAreaM2)}</span>
        </span>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-2xl bg-surface-raised px-4 py-3">
          <div className="text-ink-soft">Mittlere Genauigkeit</div>
          <div className="mt-1 font-medium text-ink">
            {averageAccuracy !== null ? formatAccuracy(averageAccuracy) : 'noch keine Daten'}
          </div>
        </div>
        <div className="rounded-2xl bg-surface-raised px-4 py-3">
          <div className="text-ink-soft">Letzter akzeptierter Punkt</div>
          <div className="mt-1 font-medium text-ink">
            {latestPoint ? formatTimestamp(latestPoint.timestamp) : 'noch keiner'}
          </div>
        </div>
      </div>

      {walkPoints.length > 0 ? (
        <div className="mt-4 rounded-2xl bg-surface-raised px-4 py-3">
          <button
            type="button"
            onClick={onToggleWalkPoints}
            aria-expanded={isWalkPointsOpen}
            className="flex w-full items-start justify-between gap-3 text-left"
          >
            <div>
              <h3 className="text-sm font-medium text-ink">Aufgenommene Weidegaenge</h3>
              <p className="mt-1 text-xs text-ink-soft">{walkPoints.length} Punkte gespeichert</p>
            </div>
            <span className="text-base text-ink">{isWalkPointsOpen ? '−' : '+'}</span>
          </button>

          {isWalkPointsOpen ? (
            <>
              {selectedWalkPoint ? (
                <div className="mt-3 rounded-2xl border border-border-soft bg-accent px-3 py-3 text-sm text-ink">
                  Ausgewaehlt: Punkt {selectedWalkPointIndex !== null ? selectedWalkPointIndex + 1 : ''}{' '}
                  um {formatPointTimestamp(selectedWalkPoint.timestamp)} mit{' '}
                  {formatAccuracy(selectedWalkPoint.accuracy)}.
                </div>
              ) : null}

              <div className="mt-3 max-h-64 space-y-2 overflow-y-auto">
                {walkPoints.map((point, index) => (
                  <div
                    key={`${point.timestamp}-${index}`}
                    className={cn(
                      'grid grid-cols-[1fr_auto] gap-3 rounded-2xl px-3 py-3 text-sm',
                      selectedWalkPointIndex === index ? 'bg-accent' : 'bg-surface-raised',
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => onSelectedWalkPointIndexChange(index)}
                      className="text-left"
                    >
                      <div className="font-medium text-ink">Punkt {index + 1}</div>
                      <div className="mt-1 text-ink-muted">
                        {point.latitude.toFixed(5)}, {point.longitude.toFixed(5)}
                      </div>
                      <div className="mt-1 text-xs text-ink-soft">
                        {formatPointTimestamp(point.timestamp)} · Genauigkeit {formatAccuracy(point.accuracy)}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveWalkPointAtIndex(index)}
                      className="rounded-2xl bg-surface-raised px-3 py-2 text-xs font-medium text-ink"
                    >
                      Entfernen
                    </button>
                  </div>
                ))}
              </div>
            </>
          ) : null}
        </div>
      ) : null}

      <form className="mt-4 space-y-4" onSubmit={onSubmit}>
        <FormField>
          <FormLabel>Pferchname</FormLabel>
          <FormInput
            value={walkName}
            onChange={(event) => onWalkNameChange(event.target.value)}
            placeholder="z. B. Weidekante Ost"
          />
        </FormField>

        <FormField>
          <FormLabel>Notiz</FormLabel>
          <FormTextarea
            rows={3}
            value={walkNotes}
            onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => onWalkNotesChange(event.target.value)}
            placeholder="optionale Notiz zum abgelaufenen Pferch"
          />
        </FormField>

        {walkError && (
          <ErrorAlert>{walkError}</ErrorAlert>
        )}

        <FormButton
          type="submit"
          disabled={isWalkSaving || walkPoints.length < 3}
          variant="primary"
          className="w-full"
        >
          {isWalkSaving ? 'Speichert ...' : 'Abgelaufenen Pferch speichern'}
        </FormButton>
      </form>
    </>
  )
}
