self.__PWA_PRECACHE_MANIFEST = {
  "version": "9nS-9CC7QjwmT24kYXQ34",
  "routes": [
    {
      "path": "/",
      "dataRoute": "/index.rsc"
    },
    {
      "path": "/_global-error",
      "dataRoute": "/_global-error.rsc"
    },
    {
      "path": "/_not-found",
      "dataRoute": "/_not-found.rsc"
    },
    {
      "path": "/care",
      "dataRoute": "/care.rsc"
    },
    {
      "path": "/enclosures",
      "dataRoute": "/enclosures.rsc"
    },
    {
      "path": "/export",
      "dataRoute": "/export.rsc"
    },
    {
      "path": "/favicon.ico",
      "dataRoute": null
    },
    {
      "path": "/herd",
      "dataRoute": "/herd.rsc"
    },
    {
      "path": "/herd/edit",
      "dataRoute": "/herd/edit.rsc"
    },
    {
      "path": "/herds",
      "dataRoute": "/herds.rsc"
    },
    {
      "path": "/session",
      "dataRoute": "/session.rsc"
    },
    {
      "path": "/sessions",
      "dataRoute": "/sessions.rsc"
    },
    {
      "path": "/settings",
      "dataRoute": "/settings.rsc"
    },
    {
      "path": "/settings/diagnostics",
      "dataRoute": "/settings/diagnostics.rsc"
    },
    {
      "path": "/work",
      "dataRoute": "/work.rsc"
    }
  ],
  "urls": [
    "/",
    "/_global-error",
    "/_next/static/9nS-9CC7QjwmT24kYXQ34/_buildManifest.js",
    "/_next/static/9nS-9CC7QjwmT24kYXQ34/_ssgManifest.js",
    "/_next/static/chunks/05f6971a.b186f38147d24bcb.js",
    "/_next/static/chunks/108-3e31b1e73a8f52f6.js",
    "/_next/static/chunks/111-7bd5d206591361dc.js",
    "/_next/static/chunks/116-f2f9a04a3154f3ab.js",
    "/_next/static/chunks/270-bdeef7556a2b2fa2.js",
    "/_next/static/chunks/301-51c87626c5034f9a.js",
    "/_next/static/chunks/457-50612cbbf301dc33.js",
    "/_next/static/chunks/4bd1b696-f9fb033f25886fd3.js",
    "/_next/static/chunks/500-5d45efbf86b8d36e.js",
    "/_next/static/chunks/661-8ffb6dade8484397.js",
    "/_next/static/chunks/67-d9df132a283ba332.js",
    "/_next/static/chunks/715-265a3ea68e14384e.js",
    "/_next/static/chunks/761-35bff67f905c157a.js",
    "/_next/static/chunks/764.87ee53f48dfad628.js",
    "/_next/static/chunks/771.5f28f782cb66257e.js",
    "/_next/static/chunks/794-32443f99e6c8f194.js",
    "/_next/static/chunks/923-ee5c0602eecb01e7.js",
    "/_next/static/chunks/953-82cbefd7f62a5284.js",
    "/_next/static/chunks/app/_global-error/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/_not-found/page-75f8e505bce85ff2.js",
    "/_next/static/chunks/app/care/page-e0a5c6b937d91e4f.js",
    "/_next/static/chunks/app/enclosures/page-cbfefeba0323412e.js",
    "/_next/static/chunks/app/export/page-e27c77b1efa025dd.js",
    "/_next/static/chunks/app/herd/edit/page-7e0783221bc94a5f.js",
    "/_next/static/chunks/app/herd/page-6423f0490da4a236.js",
    "/_next/static/chunks/app/herds/[id]/edit/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/herds/[id]/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/herds/page-59522207c1bfe9e5.js",
    "/_next/static/chunks/app/layout-b226af37028f0a40.js",
    "/_next/static/chunks/app/page-df7b599a0777dc3f.js",
    "/_next/static/chunks/app/session/page-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/app/sessions/page-e4a400451b289cf1.js",
    "/_next/static/chunks/app/settings/diagnostics/page-53a3a6fded7da45f.js",
    "/_next/static/chunks/app/settings/page-5045a6752e1585e5.js",
    "/_next/static/chunks/app/work/page-2133d292f76ae16b.js",
    "/_next/static/chunks/framework-747382f602876dbf.js",
    "/_next/static/chunks/main-a0d0ee2abdc892cd.js",
    "/_next/static/chunks/main-app-1a10d56d48ecb598.js",
    "/_next/static/chunks/next/dist/client/components/builtin/app-error-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/forbidden-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/global-error-4c0d88c11e8d3eeb.js",
    "/_next/static/chunks/next/dist/client/components/builtin/not-found-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/next/dist/client/components/builtin/unauthorized-1ddd8f14f997b1c6.js",
    "/_next/static/chunks/polyfills-42372ed130431b0a.js",
    "/_next/static/chunks/webpack-c015e7b82568a142.js",
    "/_next/static/css/badba33cb5f06cfc.css",
    "/_next/static/css/c45b4ffe24886989.css",
    "/_next/static/media/27834908180db20f-s.p.woff2",
    "/_not-found",
    "/care",
    "/enclosures",
    "/export",
    "/favicon.ico",
    "/file.svg",
    "/globe.svg",
    "/herd",
    "/herd/edit",
    "/herds",
    "/icon-512-maskable.png",
    "/icon-512.png",
    "/icon.png",
    "/manifest.webmanifest",
    "/next.svg",
    "/offline.html",
    "/session",
    "/sessions",
    "/settings",
    "/settings/diagnostics",
    "/vercel.svg",
    "/window.svg",
    "/work"
  ]
};
