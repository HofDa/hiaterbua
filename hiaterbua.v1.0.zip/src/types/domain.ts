import type * as GeoJSON from 'geojson'

export type Species = 'cattle' | 'sheep' | 'goats' | 'horses' | 'other'

export type EnclosureMethod = 'draw' | 'walk'

export type SessionStatus = 'active' | 'paused' | 'finished'

export type WorkStatus = 'active' | 'paused' | 'finished'

export type WorkType =
  | 'herding'
  | 'driving'
  | 'fence'
  | 'control'
  | 'water'
  | 'transport'
  | 'other'

export type WorkActivityId =
  | 'guided_access_to_grazing_animals'
  | 'guided_lead_grazing_animals'
  | 'guided_herd_grazing_animals'
  | 'guided_collect_grazing_animals'
  | 'guided_fence_work'
  | 'guided_overnight_fence_work'
  | 'guided_material_shift'
  | 'guided_water_supply'
  | 'guided_check_grazing_animals'
  | 'guided_check_lambing'
  | 'guided_check_herding_dogs'
  | 'guided_check_guard_dogs'
  | 'guided_brush_clearing_with_grazers'
  | 'guided_detangling'
  | 'guided_follow_up_grazing'
  | 'guided_fence_work_for_brush_clearing'
  | 'guided_trampling_via_overdrive'

export type SessionEventType =
  | 'water'
  | 'rest'
  | 'move'
  | 'disturbance'
  | 'note'
  | 'start'
  | 'pause'
  | 'resume'
  | 'stop'

export type WorkEventType = 'start' | 'pause' | 'resume' | 'stop' | 'note'

export type MapBaseLayer = 'south-tyrol-basemap' | 'south-tyrol-orthophoto-2023'

export type SyncStatus = 'dirty' | 'synced' | 'syncing' | 'error'

export type HabitatType =
  | 'dry_grassland'
  | 'semi_dry_grassland'
  | 'nardus_grassland'
  | 'productive_pasture'
  | 'dwarf_shrub_heath'
  | 'wood_pasture'
  | 'other'

export type CareGoalId =
  | 'use_grass_herbs'
  | 'reduce_thatch'
  | 'reduce_scrub'
  | 'keep_structure'
  | 'create_open_soil'
  | 'protect_plants'
  | 'avoid_nutrients'

export type CareTargetUsePercent = 25 | 50 | 75 | 100

export interface CarePlantReference {
  name: string
}

export interface LocalRecordMetadata {
  deletedAt?: string | null
  deviceId?: string | null
  syncStatus?: SyncStatus
  lastLocalChangeAt?: string | null
}

export type FieldDiagnosticLevel = 'info' | 'warning' | 'error'

export interface FieldDiagnosticEvent {
  id: string
  type: string
  level: FieldDiagnosticLevel
  message: string
  createdAt: string
  online: boolean
  route?: string
  userAgent?: string
  activeWorkSessionId?: string | null
  activeGrazingSessionId?: string | null
  activeRecordingId?: string | null
  details?: unknown
}

export interface MapTileRecord {
  url: string
  blob: Blob
  contentType?: string
  status: number
  statusText?: string
  updatedAt: string
}

export interface Herd extends LocalRecordMetadata {
  id: string
  name: string
  fallbackCount?: number | null
  notes?: string
  isArchived: boolean
  createdAt: string
  updatedAt: string
}

export interface Animal extends LocalRecordMetadata {
  id: string
  herdId: string
  earTag: string
  species: Species
  name?: string
  notes?: string
  isArchived: boolean
  createdAt: string
  updatedAt: string
}

export interface Enclosure extends LocalRecordMetadata {
  id: string
  name: string
  method: EnclosureMethod
  rootEnclosureId?: string | null
  version?: number | null
  supersededByEnclosureId?: string | null
  supersededAt?: string | null
  geometry: GeoJSON.Polygon | null
  areaM2: number
  areaHa: number
  herdId?: string | null
  notes?: string
  avgAccuracyM?: number | null
  pointsCount?: number | null
  createdAt: string
  updatedAt: string
}


export interface ConservationPlan extends LocalRecordMetadata {
  id: string
  enclosureId: string
  habitatType: HabitatType
  goals: CareGoalId[]
  targetUsePercent: CareTargetUsePercent
  protectedPlants: CarePlantReference[]
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface SurveyArea extends LocalRecordMetadata {
  id: string
  name: string
  geometry: GeoJSON.Polygon | GeoJSON.MultiPolygon
  notes?: string
  areaM2: number
  areaHa: number
  createdAt: string
  updatedAt: string
  importOrder?: number
}

export interface EnclosureAssignment extends LocalRecordMetadata {
  id: string
  enclosureId: string
  herdId: string
  count?: number | null
  startTime?: string | null
  endTime?: string | null
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface GrazingSession extends LocalRecordMetadata {
  id: string
  herdId: string
  animalCount?: number | null
  status: SessionStatus
  startTime: string
  endTime?: string | null
  durationS: number
  movingTimeS: number
  distanceM: number
  avgSpeedMps?: number | null
  avgAccuracyM?: number | null
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface WorkSession extends LocalRecordMetadata {
  id: string
  type: WorkType
  activityId?: WorkActivityId | null
  status: WorkStatus
  herdId?: string | null
  enclosureId?: string | null
  startTime: string
  endTime?: string | null
  activeSince?: string | null
  durationS: number
  reminderIntervalMin?: number | null
  lastReminderAt?: string | null
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface WorkEvent extends LocalRecordMetadata {
  id: string
  workSessionId: string
  timestamp: string
  type: WorkEventType
  comment?: string
  createdAt?: string
  updatedAt?: string
}

export interface TrackPoint extends LocalRecordMetadata {
  id: string
  sessionId?: string | null
  enclosureWalkId?: string | null
  seq: number
  timestamp: string
  lat: number
  lon: number
  accuracyM?: number | null
  speedMps?: number | null
  headingDeg?: number | null
  accepted: boolean
  createdAt?: string
  updatedAt?: string
}

export interface SessionEvent extends LocalRecordMetadata {
  id: string
  sessionId: string
  timestamp: string
  type: SessionEventType
  lat?: number | null
  lon?: number | null
  comment?: string
  createdAt?: string
  updatedAt?: string
}

export interface AppSettings {
  id: 'app'
  userName: string
  language: 'de'
  mapBaseLayer: MapBaseLayer
  gpsAccuracyThresholdM: number
  gpsMinTimeS: number
  gpsMinDistanceM: number
  gpsMaxSpeedMps: number
  tileCachingEnabled: boolean
  theme: 'system' | 'light'
  // ISO timestamp of the last successful full export; device-local backup
  // bookkeeping (intentionally not carried across import).
  lastExportAt?: string
}
